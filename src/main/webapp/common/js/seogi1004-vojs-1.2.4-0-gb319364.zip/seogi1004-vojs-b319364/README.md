JavaScript library for UI development

For Docs, License, Tests, and pre-packed downloads, see:
http://seogi1004.github.com/vojs/

Many thanks to our contributors:
https://github.com/seogi1004/vojs
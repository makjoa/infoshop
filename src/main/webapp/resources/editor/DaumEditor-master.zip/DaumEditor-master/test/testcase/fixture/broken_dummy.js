EditorJSLoader.readyState = "loading";
var Dummy = { };